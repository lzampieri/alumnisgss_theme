<div class="title-box">
    <h2 class="title-tag">
        <?php the_title(); ?>
    </h2>
</div>