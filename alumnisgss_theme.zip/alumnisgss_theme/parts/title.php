<div class="flex flex-row items-center justify-center
            w-full pt-32">
    <h2 class="
        text-3xl md:text-6xl font-bold w-5/6 md:w-2/5 py-4
        border-y-4 border-details-bg rounded
        text-body-tx text-center">
        <?php the_title(); ?>
    </h2>
</div>