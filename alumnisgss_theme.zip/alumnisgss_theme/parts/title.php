<div class="flex flex-row items-center justify-center
            w-full pt-32">
    <h2 class="
        text-3xl md:text-6xl font-bold two-fifths py-4
        border-y-4 border-details-bg rounded
        text-body-tx text-center">
        <?php the_title(); ?>
    </h2>
</div>